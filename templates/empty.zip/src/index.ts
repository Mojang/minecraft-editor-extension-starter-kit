import { registerEmptyExtension } from "./empty"

registerEmptyExtension();