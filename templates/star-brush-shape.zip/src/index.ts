import { registerStarBrushExtension } from "./star-brush-shape"

registerStarBrushExtension();