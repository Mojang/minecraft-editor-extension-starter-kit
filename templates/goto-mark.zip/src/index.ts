import { registerGotoMarkExtension } from "./goto-mark"

registerGotoMarkExtension();