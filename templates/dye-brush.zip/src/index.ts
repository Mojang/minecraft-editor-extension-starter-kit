import { registerDyeBrushExtension } from "./dye-brush"

registerDyeBrushExtension();