import { registerMinimalExtension } from "./minimal"

registerMinimalExtension();