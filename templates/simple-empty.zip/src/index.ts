import { registerSimpleEmptyTool } from "./SimpleEmptyTool"

registerSimpleEmptyTool();