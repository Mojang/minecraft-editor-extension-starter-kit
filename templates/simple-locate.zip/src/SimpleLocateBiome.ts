// Copyright (c) Mojang AB.  All rights reserved.

import { VECTOR3_ZERO, Vector3Utils } from '@minecraft/math';
import {
    ActionTypes,
    IDropdownItem,
    IPlayerUISession,
    ISimpleToolOptions,
    ISimpleToolPaneComponent,
    InputModifier,
    KeyboardKey,
    SimpleToolWrapper,
    bindDataSource,
    registerEditorExtension,
} from '@minecraft/server-editor';
import { BiomeTypes, Player, Vector3 } from '@minecraft/server';

enum LocateMode {
    Biome = 0,
    Structure,
}

type LocateSelectorType = {
    locateMode: LocateMode;
};

type LocateBiomeSourceType = {
    biomeId: number;
    biomePos: Vector3;
};

type ResultsType = {
    foundType: string;
    foundPos: Vector3;
};

// Implementation of a simple tool that allows the player to locate a biome
// This tool demonstrates the use of the SimpleToolWrapper class (and the associated
// ISimpleTool<T>Options interfaces)
export class SimpleLocate extends SimpleToolWrapper {
    private _results: ResultsType = {
        foundType: '',
        foundPos: VECTOR3_ZERO,
    };

    // Activate the results pane with the found biome/structure and position in the
    // world.  This uses the SimpleToolWrapper's showPane method to display the results
    // in a pre-constructed pane which is generally hidden until results are valid.
    activateResultsPane(biome: string, pos: Vector3): void {
        this.simpleTool.logInfo(`Found ${biome} at ${Vector3Utils.toString(pos)}`);

        this._results.foundType = biome;
        this._results.foundPos = pos;

        // Hopefully, we'll be able to get rid of this function in the near future.
        // reconstructing the pane is a last-resort hack to get the pane to update
        // certain UI components which do not currently support dynamic data binding.
        // It's a necessary evil for now, but we're working on a better solution.
        // We certainly don't recommend doing this more than necessary - it causes a
        // lot of classes to be re-created and can be very slow, especially if there
        // are a lot of child panes and UI components.
        const foundPane = this.simpleTool.pane.findPane('results-found');
        foundPane?.reconstructPane();

        // Show the results pane (this will cause the other sibling panes
        // (like 'results-notfound') to be hidden because they're flagged as mutually
        // exclusive)
        this.simpleTool.showPane('results-found');
    }

    activateNoResultsPane(): void {
        // Show the results-notfound pane (this will cause the other sibling panes
        // (like 'results-found') to be hidden because they're flagged as mutually
        // exclusive)
        this.simpleTool.showPane('results-notfound');
    }

    hideResultsPane(): void {
        // Hide the results pane
        // We generally do this when we're changing options or don't have a valid set
        // of results to display.
        // Note that this will hide both the `results-found` and `results-notfound` panes
        // because they're child panes of this one
        this.simpleTool.hidePane('results');
    }

    // The 'typeSelector' pane is the initial pane that allows the player to select the
    // type of 'thing' they want to locate (biome or structure).  This function builds
    // a dropdown containing the two options.
    // The onChange event handler is used to show the appropriate sub-pane based on the
    // selection.
    buildTypeSelectionPane(component: ISimpleToolPaneComponent): void {
        const actualPane = component.pane;

        // We create a data binding between this pane/server script and the client-side
        // UI component.  This binding allows changes here to be reflected in the UI and
        // changes made to the UI to be reflected here.
        // It creates a bi-directional networking link between the client and server.
        // We use this to ensure that the selected type is always up-to-date.
        const locatorType: LocateSelectorType = bindDataSource(actualPane, {
            locateMode: LocateMode.Biome,
        });

        // Create a dropdown with two options: Biome and Structure
        // and an event handler to show the appropriate sub-pane when the selection changes
        actualPane.addDropdown(locatorType, 'locateMode', {
            titleStringId: 'sample.simplelocate.tool.locatetype.title',
            titleAltText: 'Locate Type',
            dropdownItems: [
                {
                    displayStringId: 'sample.simplelocate.tool.locatetype.biome',
                    displayAltText: 'Biome',
                    value: LocateMode.Biome,
                },
                {
                    displayStringId: 'sample.simplelocate.tool.locatetype.structure',
                    displayAltText: 'Structure',
                    value: LocateMode.Structure,
                },
            ],
            onChange: (_obj: object, _property: string, _oldValue: object, _newValue: object) => {
                const mode = _newValue as unknown as LocateMode;
                if (mode === LocateMode.Biome) {
                    component.simpleTool.showPane('type-biome');
                } else {
                    component.simpleTool.showPane('type-structure');
                }
                component.simpleTool.hidePane('results');
            },
        });
    }

    buildBiomeSearchPane(component: ISimpleToolPaneComponent): void {
        const actualPane = component.pane;

        const biomeType: LocateBiomeSourceType = bindDataSource(actualPane, {
            biomeId: 0,
            biomePos: VECTOR3_ZERO,
        });

        const listOfBiomes = BiomeTypes.getAll().map((v, i) => {
            const names = v.id;
            const item: IDropdownItem = {
                displayAltText: names.replace('minecraft:', '').replace('_', ' '),
                displayStringId: names,
                value: i,
            };
            return item;
        });

        actualPane.addDropdown(biomeType, 'biomeId', {
            titleStringId: 'sample.simplelocate.tool.biome.title',
            titleAltText: 'Biome',
            dropdownItems: listOfBiomes,
            onChange: (_obj: object, _property: string, _oldValue: object, _newValue: object) => {
                component.simpleTool.hidePane('results');
            },
        });

        const locateBiomeAction = component.session.actionManager.createAction({
            actionType: ActionTypes.NoArgsAction,
            onExecute: () => {
                const biome = BiomeTypes.getAll()[biomeType.biomeId].id;
                const player: Player = component.session.extensionContext.player;
                const biomePos = player.dimension.findClosestBiome(player.location, biome);
                if (biomePos) {
                    this.activateResultsPane(biome, biomePos);
                } else {
                    this.activateNoResultsPane();
                }
            },
        });

        actualPane.addButton(locateBiomeAction, {
            titleStringId: 'sample.simplelocate.tool.biome.find',
            titleAltText: 'Find Biome',
            visible: true,
            icon: 'pinIcon',
        });
    }

    buildStructurePane(component: ISimpleToolPaneComponent): void {
        const actualPane = component.pane;
        actualPane.addText({ t: 'Structure searching is not currently supported' }, 't', {
            border: true,
            valueStringId: 'sample.simplelocate.tool.structure.message',
        });
    }

    buildResultsPane(component: ISimpleToolPaneComponent): void {
        const actualPane = component.pane;
        actualPane.addText({ text: `Found ${this._results.foundType}` }, 'text');

        actualPane.addVector3(this._results, 'foundPos', {
            titleAltText: 'Found At',
            titleStringId: 'sample.simplelocate.tool.results.foundat',
            enable: false,
            visible: true,
        });

        actualPane.addButton(
            component.session.actionManager.createAction({
                actionType: ActionTypes.NoArgsAction,
                onExecute: () => {
                    const pos = this._results.foundPos;
                    component.session.extensionContext.player.teleport(pos);
                },
            }),
            {
                titleAltText: `Jump To Location`,
                titleStringId: 'sample.simplelocate.tool.results.goto',
            }
        );
    }

    buildNoResultsPane(component: ISimpleToolPaneComponent): void {
        const actualPane = component.pane;
        actualPane.addText({ t: 'No Results Found' }, 't', {
            border: true,
            valueStringId: 'sample.simplelocate.tool.results.notfound',
        });
    }

    constructor(session: IPlayerUISession) {
        super();

        const toolOptions: ISimpleToolOptions = {
            name: 'Simple Locate Biome',
            activationKeyBinding: {
                button: KeyboardKey.KEY_L,
                buttonModifier: InputModifier.Control | InputModifier.Shift,
            },

            propertyPaneOptions: {
                id: 'pane',
                titleStringId: 'sample.simplelocate.tool.title',
                titleAltText: 'Locate',

                childPaneInitiallyVisible: 'typeSelector',

                // There are 2 sub-panes in the root window, and 2 sub-panes in the first sub-pane
                // 1        typeSelector            - The Locate Type Selector
                //  1-1         type-biome          - The Biome Locator
                //  1-2         type-structure      - The Structure Locator
                // 2        results                 - The results
                //  2-1         results-found       - Actual Results
                //  2-2         results-notfound    - Not Found warning
                childPanes: [
                    {
                        id: 'typeSelector',
                        titleAltText: 'Locate Type',
                        titleStringId: 'sample.simplelocate.tool.locatetype.title',

                        onBeginFinalize: component => this.buildTypeSelectionPane(component),

                        childPaneInitiallyVisible: 'type-biome',
                        childPanesMutuallyExclusive: true,

                        childPanes: [
                            {
                                id: 'type-biome',
                                titleAltText: 'Find Biome',
                                titleStringId: 'sample.simplelocate.tool.locatetype.biome.title',
                                onBeginFinalize: component => this.buildBiomeSearchPane(component),
                            },
                            {
                                id: 'type-structure',
                                titleAltText: 'Find Structure',
                                titleStringId: 'sample.simplelocate.tool.locatetype.structure.title',
                                onBeginFinalize: component => this.buildStructurePane(component),
                            },
                        ],
                    },
                    {
                        id: 'results',
                        titleAltText: 'Results',
                        titleStringId: 'sample.simplelocate.tool.results.title',

                        childPanesMutuallyExclusive: true,

                        childPanes: [
                            {
                                id: 'results-found',
                                titleAltText: 'Found',
                                titleStringId: 'sample.simplelocate.tool.results.foundat.title',

                                onBeginFinalize: component => this.buildResultsPane(component),
                            },
                            {
                                id: 'results-notfound',
                                titleAltText: 'No Results',
                                titleStringId: 'sample.simplelocate.tool.results.notfound.title',

                                onBeginFinalize: component => this.buildNoResultsPane(component),
                            },
                        ],
                    },
                ],
            },
        };

        this.setupSimpleTool(session, toolOptions);
    }
}

/**
 * Provides a "Simple Biome Locate" extension to demonstrate the new Simple Tool wrapper system
 * @beta
 */
export function registerSimpleLocateBiomeTool() {
    registerEditorExtension(
        'simple-locate-sample',
        uiSession => {
            uiSession.log.debug(`Initializing extension [${uiSession.extensionContext.extensionInfo.name}]`);

            // Just instantiate the tool and return it to the editor - the editor will deal with cleaning up
            // and shutting down the tool when it's no longer required
            const simpleLocateTool = new SimpleLocate(uiSession);

            // Return an array of things for the editor to clean up.
            // If you wanted to, you can create many individual tools in this single register function
            // and return them all in the array, and the editor will clean them all up when the extension
            // is unloaded
            return [simpleLocateTool];
        },
        uiSession => {
            uiSession.log.debug(
                `Shutting down extension [${uiSession.extensionContext.extensionInfo.name}] for player [${uiSession.extensionContext.player.name}]`
            );
        },
        {
            description: '"Simple Locate Biome Tool" Sample Extension',
            notes: 'by Dave & Mitch (https://youtu.be/KyElxl_j4Wc?si=Mem99VTjqAE_UE2T)',
        }
    );
}
