import { registerSimpleLocateBiomeTool } from "./SimpleLocateBiome"

registerSimpleLocateBiomeTool();