import { registerTreeGeneratorExtension } from "./tree-generator"

registerTreeGeneratorExtension();