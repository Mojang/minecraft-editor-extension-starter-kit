import { registerFarmGeneratorExtension } from "./farm-generator"

registerFarmGeneratorExtension();