import { registerCameraGrapple } from "./camera-grapple"

registerCameraGrapple();