import { registerPortalGeneratorExtension } from "./portal-generator"

registerPortalGeneratorExtension();